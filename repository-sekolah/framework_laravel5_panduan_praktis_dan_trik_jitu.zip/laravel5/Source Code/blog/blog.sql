-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 12 Mei 2015 pada 10.05
-- Versi Server: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
`id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL DEFAULT '0',
  `commenter` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data untuk tabel `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `commenter`, `email`, `comment`, `created_at`, `updated_at`) VALUES
(1, 34, 'Akhmad Dharma', 'akhmad_dharma@yahoo.com', 'Wah,,sayang gak ada..bakalan seru kalo ada spiderman tuh..!!!', '2015-05-12 11:05:07', '2015-05-12 11:05:07'),
(2, 30, 'Abimanyu', 'dharma@intakindo.or.id', 'Wah banyak amat ...', '2015-05-12 11:06:39', '2015-05-12 11:06:39'),
(3, 35, 'Kresna', 'akhmad.ama@bsi.ac.id', 'Wah,,pasti gw tonton nih konser...', '2015-05-12 11:22:30', '2015-05-12 11:22:30'),
(4, 35, 'Wulan', 'wulan27@gmail.com', 'Wah, dateng lagi..pasti keren deh konsernya..', '2015-05-12 11:23:15', '2015-05-12 11:23:15'),
(5, 31, 'Jonathan', 'joni@joni.com', 'Panteslah..emang seru banget filmnya..', '2015-05-12 11:24:15', '2015-05-12 11:24:15'),
(6, 34, 'Dody', 'dody123@gmail.com', 'Kalau perlu Superman sekalian sama batman..', '2015-05-12 11:25:25', '2015-05-12 11:25:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2015_05_06_111058_buat_table_post', 1),
('2015_05_06_111129_buat_table_comments', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
`id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `read_more` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comment_count` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;

--
-- Dumping data untuk tabel `posts`
--

INSERT INTO `posts` (`id`, `title`, `read_more`, `content`, `image`, `comment_count`, `created_at`, `updated_at`) VALUES
(35, 'Pasti Kunjungi Jakarta, Konser Maroon 5 Akan Seistimewa Ini', 'Setelah sukses menggebrak Jakarta pada tahun 2011 dan 2012 sila, Maroon 5 akhirnya kembali lagi datang ke ibu kota. Melalui sebuah konser bertajuk Maroon 5 Live In Jakarta 2015, Adam Levine dkk akan kembali membawakan ke', 'Setelah sukses menggebrak Jakarta pada tahun 2011 dan 2012 sila, Maroon 5 akhirnya kembali lagi datang ke ibu kota. Melalui sebuah konser bertajuk Maroon 5 Live In Jakarta 2015, Adam Levine dkk akan kembali membawakan keseruan maksimal lewat lagu-lagu mereka.\r\n\r\nBagaimana tidak, reputasi Maroon 5 sebagai salah satu band besar sudah mereka buktikan di dunia musik internasional. Album band asal Amerika ini termasuk yang paling baru V sukses mencuri perhatian dan diterima baik oleh semua orang. Dua konser yang pernah diadakan di Jakarta pun terbukti selalu berhasil menyedot animo penonton tanah air.\r\n\r\nKonser spesial ini rencananya akan digelar pada tanggal 23 September 2015 nanti. Bertempat di Indonesia Convention Exhibition (ICE), Maroon 5 Live In Jakarta 2015 akan menjadi ajang pembuktian kualitas band yang pernah menyabet Grammy sebagai band rock terbaik tersebut.\r\n\r\n Konser in dipastikan akan super seru sejak awal. bagaimana tidak, Dirty Loops didatangkan lagsung dari swedia untuk menjadi band pembuka dari konser akbar ini. Musik jazz yang dipadukan dengan warna R&B dan pop elektronik dijamin akan membuatmu bergoyang sepanjang acara.\r\n\r\nTak perlu menunggu waktu lama lagi, tiket untuk konser ini akan mulai dijual pada tanggal 8 Mei 2015 nanti. Ada banyak gerai tiket yang bisa kamu serbu seperti Disctarra yang tentunya banyak tersebar. Kamu juga bisa memesannya secara online melalui www.maroon5jakarta.com.\r\n\r\nJadi tunggu apa lagi, segera siapkan dirimu untuk memesan tiket konser Maroon 5 ini karena kamu pastinya akan sangat rugi banget bila sampai melewatkan aksi dari pelantun lagu Sugar ini. \r\n', 'uploads/70944.jpg', 2, '2015-05-12 11:21:28', '2015-05-12 11:23:15'),
(34, 'Wah, Ternyata Spider-Man dan Captain Marvel Nyaris Muncul di ''Avengers 2''', 'WowKeren.com - "Avengers: Age of Ultron" saat ini sedang membius para penggemar superhero Marvel. Film kedua ini pun masih dijejali banyak superhero mulai dari tim Avengers hingga kemunculan tokoh baru seperti The Vision', 'WowKeren.com - "Avengers: Age of Ultron" saat ini sedang membius para penggemar superhero Marvel. Film kedua ini pun masih dijejali banyak superhero mulai dari tim Avengers hingga kemunculan tokoh baru seperti The Vision. Namun sebenarnya masih ada lebih banyak lagi lho!\r\n\r\nHal tersebut dibeberkan sang sutradara, Joss Whedon, dalam wawancara dengan Empire baru-baru ini. Ia mengungkap bahwa nyaris saja memunculkan "Spider-Man" di "Age of Ultron". Selain manusia laba-laba juga ada niatan untuk menghadirkan Captain Marvel.\r\n\r\n"Itu akan sangat bagus jika kita bisa menambah beberapa (superhero) lagi. Jika kita bisa menghadirkan Captain Marvel," ucap Josh. "Dan kami benar-benar membicarakannya (bernegosiasi)."\r\n\r\n"Untuk Spider-Man kami juga bisa melakukannya (memunculkan di ''Age of Ultron) karena Sony sudah mendekati kami sejak film pertama untuk melakukan sedikit kolaborasi. Jadi kami berpikir untuk memunculkan keduanya, tapi tidak tercapai kesepakatan."\r\n\r\nTampaknya kesepakatan tersebut tidak tercapai karena tim produksi "Avengers 2" sudah "tutup pintu". "Mereka bersikap, ''Kami membuat film ''Captain Marvel'' dan sudah punya Spider-Man! dan aku hanya merespoon, ''Aku sudah mengunci filmku'', terima kasih untuk waktunya," beber Josh blak-blakan.\r\n\r\nSaat ini Sony masih mencari sosok pengganti Andrew Garfield sebagai Peter Parker yang baru. Dua nama yang berpeluang besar memerankan Spider-Man generasi baru adalah Asa Butterfield dan Tom Holland. (wk/mr)\r\n\r\nRead more: http://www.wowkeren.com/berita/tampil/00073965.html#ixzz3ZdfJOBf3\r\n', 'uploads/86347.jpg', 2, '2015-05-09 18:11:43', '2015-05-12 11:25:25'),
(32, 'Avenger ''The Age Of Ultron'' Sukses merebut pasar', 'Avenger ''The Age Of Ultron'' Sukses merebut pasar senen Avenger ''The Age Of Ultron'' Sukses merebut pasar senen Avenger ''The Age Of Ultron'' Sukses merebut pasar senen Avenger ''The Age Of Ultron'' Sukses merebut pasar senen ', 'Avenger ''The Age Of Ultron'' Sukses merebut pasar senen Avenger ''The Age Of Ultron'' Sukses merebut pasar senen Avenger ''The Age Of Ultron'' Sukses merebut pasar senen Avenger ''The Age Of Ultron'' Sukses merebut pasar senen Avenger ''The Age Of Ultron'' Sukses merebut pasar senen Avenger ''The Age Of Ultron'' Sukses merebut pasar senen ', 'uploads/31005.jpg', 0, '2015-05-09 15:56:12', '2015-05-12 11:23:43'),
(31, '''FURIOUS 7'' punya pendapatan lebih besar daripada 16 negara', 'Film FAST AND FURIOUS 7 masih banyak dibicarakan di berbagai dunia dan tentunya jadi box office. Salah satu kesuksesan franchise ini adalah penampilan terakhir kalinya Paul Walker dalam sebuah film yang membuat banyak fa', 'Film FAST AND FURIOUS 7 masih banyak dibicarakan di berbagai dunia dan tentunya jadi box office. Salah satu kesuksesan franchise ini adalah penampilan terakhir kalinya Paul Walker dalam sebuah film yang membuat banyak fans terharu.\r\n\r\nKesuksesan FURIOUS 7 salah satunya ditunjukkan oleh besarnya jumlah pendapatan. Dalam 17 hari saja, film yang dibintangi oleh Vin Diesel dan Jason Statham ini sukses meraih US$ 1 miliar atau sekitar Rp 13 triliun. Pencapaian ini memecahkan rekor-rekor film AVATAR, THE AVENGERS, dan HARRY POTTER AND THE DEATHLY HALLOWS yang mendapat pendapatan sebesar itu dalam waktu 19 hari.\r\n\r\nSatu hal yang unik dari angka fantastis tersebut adalah jumlahnya yang lebih besar daripada pendapatan beberapa negara dalam satu tahun. Seperti dilansir situs The Independent, berdasarkan data dari International Monetary Fund (badan finansial PBB yang biasanya disingkat jadi IMF), pendapatan FURIOUS 7 lebih besar daripada GDP milik Gambia, Guinea-Bissau, Vanuatu, Grenada, Saint Kitts dan Nevis, Saint Vincent dan Grenadines, Samoa, Komoro, Dominika, Tonga, Federasi Mikronesia, Sao Tome dan Prinsipe, Palau, Kepulauan Marshall, Kiribati dan Tuvalu.\r\n\r\n GDP (Gross Domestic Product) atau produk domestik bruto adalah nilai keseluruhan semua barang dan jasa yang diproduksi di dalam wilayah tersebut dalam jangka waktu tertentu, biasanya per tahun. Jadi artinya, apa yang telah didapat oleh FURIOUS 7 dalam 17 hari lebih besar daripada pendapatan negara-negara tersebut di atas selama satu tahun.\r\n\r\n"Kami sangat bangga melihat FAST AND FURIOUS sebagai satu-satunya franchise live-action yang sukses di box office. Para pemain, pembuat, dan seluruh keluarga Universal berhak dapat kredit atas kerja kerasnya membuat FURIOUS 7 jadi sebuah film besar," ujar Nick Carpou, presiden Universal Pictures.\r\n\r\nMelihat besarnya pendapatan FURIOUS 7, sampai ada yang bercanda menjadikan film ini jadi sebuah negara. Ada-ada saja ya :)', 'uploads/64935.jpg', 1, '2015-05-09 13:29:28', '2015-05-12 11:24:15'),
(30, 'Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun', 'Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron ', 'Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun Minggu Pertama, Avengers: Age of Ultron Raup Rp 2,6 Triliun', 'uploads/59464.jpg', 1, '2015-05-09 13:26:02', '2015-05-12 11:06:39'),
(33, 'Musim Dingin Kembali Datang, "Frozen 2" Dipastikan Segera Tayang', 'Disney akhirnya mengumumkan kehadiran sekuel film animasi Frozen (2013) secara resmi. Kelanjutan kisah kakak-adik Elsa dan Anna ini dipastikan Disney melalui akun Twitternya. \r\n\r\n"Ramalan cuaca: Musim dingin akan datang.', 'Disney akhirnya mengumumkan kehadiran sekuel film animasi Frozen (2013) secara resmi. Kelanjutan kisah kakak-adik Elsa dan Anna ini dipastikan Disney melalui akun Twitternya. \r\n\r\n"Ramalan cuaca: Musim dingin akan datang. @DisneyAnimation sedang mengembangkan #Frozen2 dengan Chris Buck dan Jennifer Lee," tulis Disney di akun resmi @Disney, Jumat (13/3/2015). \r\n\r\nChris Buck dan Jennifer Lee merupakan duet sutradara yang menggarap Frozen perdana. Selain itu, dilansir CNN, Frozen 2 juga akan kembali diproduseri oleh Peter Del Vecho.\r\n\r\nDilansir dari AFP, Jennifer Lee pun mengumumkan secara resmi kehadiran Frozen 2. "Akhirnya, saya bisa bilang - FROZEN 2!!!! Saya sangat senang menciptakan ini didampingi keluarga Frozen," tulis Lee di akun Twitternya.\r\n\r\nFrozen memang film animasi tersukses jika dinilai berdasarkan jumlah pendapatan kotor. Film yang merupakan adaptasi dari dongeng Snow Queen garapan Hans Christian Andersen ini tercatat mendapatkan 1.279.852.693 dollar AS. Selain menjadi animasi tersukses, Frozen berada di peringkat lima film paling laris sepanjang sejarah.\r\n\r\nAngka yang didapatkan itu tentu saja baru dihitung dari pemutaran film di bioskop resmi, dan belum menghitung dari hasil penjualan merchandise. Penjualan merchandise tentu menambah pundi-pundi kekayaan Disney dengan menjual karakter Elsa dan Anna yang masuk di daftar Disney''s Princess terbaru. Belum lagi karakter lucu seperti Olaf si boneka salju Olaf dan rusa kutub bernama Sven.\r\n\r\nFrozen dianggap menjadi film yang disukai orang tua karena menghadirkan kisah mengharukan tentang hubungan dua saudara Anna dan Elsa. Film ini juga menjadi bagian dari dekonstruksi cerita yang dilakukan Disney, dengan menghadirkan karakter sang putri yang tidak hanya menunggu kehadiran pangeran yang mengendarai kuda putih.\r\n\r\nSelain itu, anak-anak juga menyukai Frozen karena lagu-lagu yang ramah dan terus ''menempel'' di telinga, seperti "Do You Want to Build a Snowman?" dan "Let It Go".\r\n\r\nSayangnya belum ada bocoran cerita dari film yang kembali dibintangi Kristen Bell dan Idina Menzel tersebut. Disney juga belum mengumumkan kapan film ini akan dirilis. Namun, tentunya film ini masih layak untuk dinantikan dan ditonton sekeluarga. ', 'uploads/93682.jpg', 1, '2015-05-09 17:54:06', '2015-05-12 11:26:24');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Akhmad Dharma Kasman', 'akhmad_dharma@yahoo.com', '$2y$10$3biVk/k8dIyTPvxw5kLbB.1KTCgId/YHGqJWRtL0GP5hosIwK2oGm', 'v4wjuq4GwufO9v4NqEk5wB6aZ4SY3sfGroIZqkQ8n5guMi3HOTNgvEODBGb1', '2015-05-08 19:24:30', '2015-05-12 14:46:14'),
(2, 'Administrator', 'admin@admin.com', '$2y$10$nDA8X0fl80Dzz7TRbGWRm.KhlEIgcrLua7l6OGDs00Jsv1DXddGdG', '1wt7TkBjqRUn4LNJGKWvzgtW0wmRByFYsTw6kqO4Hv0I17j75eQKNyxsufnk', '2015-05-12 05:26:49', '2015-05-12 12:27:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
 ADD KEY `password_resets_email_index` (`email`), ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
 ADD PRIMARY KEY (`id`), ADD FULLTEXT KEY `search` (`title`,`content`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
